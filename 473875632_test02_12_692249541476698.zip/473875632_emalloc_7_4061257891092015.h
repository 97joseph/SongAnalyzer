/** @file emalloc.h
 *  @brief Function prototypes for the emalloc wrapper.
 *
 */
#ifndef _EMALLOC_H_
#define _EMALLOC_H_

void *emalloc(size_t);

#endif
