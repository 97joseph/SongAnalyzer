# Songs-database
program that stores and displays songs in C  

# Functionality
The program is be capable of following functions:

load existing database into memory
add new song entry to the database
save the data into a file
display all songs of a user selected artist.
display all details of the songs of a user selected album
list all songs that were released in a user selected year
list all songs of a user selected genre

For details, refer to Users' Manual (User_guide) and Developers Documentation (Dev_doc)
